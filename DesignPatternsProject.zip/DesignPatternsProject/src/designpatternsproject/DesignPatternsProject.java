/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package designpatternsproject;

/**
 *
 * @author rog91
 */
public class DesignPatternsProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Subject fashionChainStores = new Store();

        Observer customer1 =new PassiveCustomer();
        Observer customer2 =new ShopaholicCustomer();
        Observer customer3 =new ShopaholicCustomer();
        
        
        fashionChainStores.addSubscriber(customer1);
        fashionChainStores.addSubscriber(customer2);
        
        fashionChainStores.notifySubscribers();
        fashionChainStores.removeSubscriber(customer1);
        
        fashionChainStores.addSubscriber(customer3);
        
        fashionChainStores.notifySubscribers();
        ShopaholicCustomer customer4 = new ShopaholicCustomer();

        customer4.performShopping();
        Observer observer4 = customer4;
        fashionChainStores.addSubscriber(observer4);
        fashionChainStores.notifySubscribers();
        customer4.setShoppingBehavior(new ShoppingOnline());
        customer4.performShopping();
        
    }
    
}
