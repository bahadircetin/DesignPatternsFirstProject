package designpatternsproject;

public interface ShoppingBehavior {
    public void shop();
}
